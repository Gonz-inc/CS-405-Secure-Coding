// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.

/* Code was modifed on 2-3-2024 by Gerardo Gonzalez.
   This code shows my work on what I have learned from
   this week. 

   Course: CS-405
*/

#include <iostream>
#include <stdexcept>

// Here I create a custom exception class that inherits properties from the std::exception abstract class.  
class customException : public std::exception {
public: 
    customException(const char* message) : std::exception(message) {}
};

bool do_even_more_custom_application_logic() {
    // Exception thrown to tell the type of error being thrown.  
    // Note a no wrapping required in this funciton because its called in do_custom_application_logic(). 
    throw std::runtime_error("Exception detected at: do_even_more_custom_application_logic.");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic() {
    
    std::cout << "Running Custom Application Logic." << std::endl;

    // Wrap to call of do_even_more_custom_application_logic implemented. 
    try {

        if (do_even_more_custom_application_logic()) {
            
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    // Derived from standard exception abstract type refrences variable e. 

    catch (const std::exception& e) {
        
        // Output stream for error message. I added a space at the end to increase the legibility. 
        std::cerr << "Exception detected at: do_custom_application_logic\n" << e.what() << std::endl;

        //throws custom exception from the created custome exception class(customException) near the top of this file. 
        throw customException("Unable to do more.");

    }
    
    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den) {
    
    // If statement to determine weather the den is equal to zero.
    if (den == 0.0) {
        // Throws a standard C++ defined exception to deal if the den(denomitor) is divided by zero.
        throw std::runtime_error("can not divide by zero.");
    }
    return (num / den);
}

void do_division() noexcept {

    // First we wrap the the call. 
    try {

    float numerator = 10.0f;
    float denominator = 0;

    // Here the function is called and passed two paramaterss(as shown above). 
    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    
    // we catch the thrown exception from the divide() method. 
    catch (const std::exception& e) {

        // We then stream an error message using cerr. 
        std::cerr << "Arethmatic exception: " << e.what() << std::endl;

    }

}

int main()
{
    std::cout << "Student: Gerardo Gonzalez\n" << std::endl;
    std::cout << "Exceptions Tests!" << std::endl;

   /* Create exception handlers that catch exceptions in this order; 
      first the custom exception. 
      then the standard exceptions. 
      and finally any uncut exceptions.
    */
    try {

        do_division();
        do_custom_application_logic();  
    }
    // first exception custom. 
    catch (const customException& customE) {
        std::cerr << "Custom Exception: " << customE.what() << std::endl;
    }
    // second exception standard. 
    catch (const std::exception& e) {
        std::cerr << "Standared Exception: " << e.what() << std::endl;
    }
    // third exception uncaught. 
    catch (...) {
        std::cerr << "Unknwown Exception: " << std::endl;
    }

}
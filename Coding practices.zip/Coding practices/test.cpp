/* Modified by Gerardo Gonzalez
   Purose was for academic purposes.
   University: SNHU 
   Date:2024/4/2
*/
// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}


// Tests add to empyt vector
TEST_F(CollectionTest, CanAddToEmptyVector)
{

    // is the collection empty?
    EXPECT_TRUE(collection->empty());
    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());
    // if not empty, what must the size be?
    EXPECT_EQ(collection->size(), 1);
}

// Tests adding five entries to vector/collection.
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // Check to see if the collection is empyt 
    EXPECT_TRUE(collection->empty());

    // If it is empyt the value should be 0
    EXPECT_EQ(collection->size(), 0);
    
    // Adds five entries. 
    add_entries(5);

    // Checks to see if the collection is not empty.
    EXPECT_FALSE(collection->empty());

    // Makes Sure that the collection size is not zero. 
    EXPECT_NE(collection->size(), 0);

    // Collection should have five entires.
    EXPECT_EQ(collection->size(), 5);


}

// Tests that the max value is greater then or equal to the provious value.
TEST_F(CollectionTest, verifyMaxSizeOfVector)
{
    // Check to see if the collection is empyt 
    EXPECT_TRUE(collection->empty());

    // Here the "GE" represents a macro for greater then equal to with two values passed in its paramaters.
    // This verifies that the max size is greater then equal to 0 entires.
    EXPECT_GE(collection->max_size(), 0);

    // Here the add one entries. 
    add_entries(1);
    
    // Then verify that the collections max size is greater then or equal to that collection. 
    EXPECT_GE(collection->max_size(), 1);

    // add five. 
    add_entries(5);

    // verify that collections max size is greater then or equal to collection. 
    EXPECT_GE(collection->max_size(), 5);

    // add ten
    add_entries(10); 

    // Verify that collections max size is greater then equal to 10 entires. 
    EXPECT_GE(collection->max_size(), 10);
}

// Tests the capacity of the vector.
TEST_F(CollectionTest, verifyCapacityOfVector)
{
    // Check to see if the collection is empyt 
    EXPECT_TRUE(collection->empty());

    // Here the "GE" represents a macro for greater then equal to with two values passed in its paramaters.
    // This verifies that the capacity is greater then equal to 0 entires.
    EXPECT_GE(collection->capacity(), 0);

    // Here the add one entries. 
    add_entries(1);

    // Then verify that the collections capacity is greater then or equal to that collection. 
    EXPECT_GE(collection->capacity(), 1);

    // add five. 
    add_entries(5);

    // verify that collections capacity is greater then or equal to collection. 
    EXPECT_GE(collection->capacity(), 5);

    // add ten
    add_entries(10);

    // Verify that collections capacity is greater then equal to 10 entires. 
    EXPECT_GE(collection->capacity(), 10);
}

// Tests the resizing of the vector or collection.
TEST_F(CollectionTest, verifyVectorResizeUp)
{
    // We add 2 entries just for comparision.
    add_entries(2); 

    // Verify that the collection has two entires. 
    EXPECT_EQ(collection->size(), 2);

    // Here we get the amount of entires in the collection.
    // Then assign its value to regSize with the same return type from size(). 
    size_t regSize = collection->size();

    // reason why we do not just resize by interger such as resize(3) which would work.
    // Is because we keep retrieve the entires and add to them instead of just resizeing the collection. 
    // which might erase the entires that represent data. 
    collection->resize(regSize + 1);

    // Verify that it increased in size.
    EXPECT_EQ(collection->size(), 3);

    // Verify that it is not the previous size. 
    EXPECT_NE(collection->size(), 2);

}

// Test the resize funciton where its resized down in a vector/collection.
TEST_F(CollectionTest, verifyVectorResizeDown) 
{
    // We add 2 entries just for comparision.
    add_entries(2);

    // Verify that the collection has two entires. 
    EXPECT_EQ(collection->size(), 2);

    // Here we get the amount of entires in the collection.
    // Then assign its value to regSize with the same return type from size(). 
    size_t regSize = collection->size();

    // Resize the collection down.  
    collection->resize(regSize - 1);

    // Verify that it decreased in size.
    EXPECT_EQ(collection->size(), 1);

    // Verify that it is not an increased size. 
    EXPECT_NE(collection->size(), 3);
}

// Test the resize vector to check that its resized to zero.
TEST_F(CollectionTest, verifyResizeVectorToZero)
{
    // We add 2 entries just for comparision.
    add_entries(2);

    // Verify that the collection has two entires. 
    EXPECT_EQ(collection->size(), 2);

    // Here we get the amount of entires in the collection.
    // Then assign its value to regSize with the same return type from size(). 
    size_t regSize = collection->size();

    // Resize the collection down TO Zero.  
    collection->resize(regSize - 2);

    // Expects the value to be 0
    EXPECT_EQ(collection->size(), 0);

    // Verify that it is not an increased size. 
    EXPECT_NE(collection->size(), 2);

}

// Test that the collection is erase.
TEST_F(CollectionTest, verifyThatCollectionIsErased)
{
    // We add 2 entries just for comparision.
    add_entries(2);

    // Verify that the collection has two entires. 
    EXPECT_EQ(collection->size(), 2);

    collection->clear();

    // Check to see if the collection is empyt 
    EXPECT_TRUE(collection->empty());

}

// Test that the colleciton is erased by a range.
TEST_F(CollectionTest, verifyEraseBeginEndOfCollection)
{
    // We add 2 entries just for comparision.
    add_entries(2);

    // Verify that the collection has two entires. 
    EXPECT_EQ(collection->size(), 2);

    // Here we create two variables that are automatically deduced from collections. 
    // This serves as a range from the beginning of the colleciton to the end of the collection. 
    auto theBegin = collection->begin();
    auto theEnd = collection->end();

    // we use the erase operation to clear the beginning and the collection.
    collection->erase(theBegin, theEnd);

    // Check to see if the collection is empyt 
    EXPECT_TRUE(collection->empty());
}

// Tests the increase of the capacity.
TEST_F(CollectionTest, verifyReserveIncreasesCapacity)
{
    add_entries(2);

    size_t regularSize = collection->size();

    EXPECT_EQ(collection->size(), 2);

    collection->reserve(regularSize + 1);

    EXPECT_EQ(collection->size(), 2);

    EXPECT_GT(collection->capacity(), 2);

}

// Tests out of range throw exception, negative test.
TEST_F(CollectionTest, verifyOutOfRangeException)
{
    add_entries(2);

    EXPECT_THROW(collection->at(3), std::out_of_range);
}

// Tests a for loop  that adds to max number but collection is less then the max number(99). 
TEST_F(CollectionTest, verifyLessThenVector)
{
    add_entries(90);

    int maxNum = 99;

    for (auto i = collection->size(); i < maxNum; i++) {
        add_entries(1);
        EXPECT_LE(collection->size(), maxNum);
    }

}

// Test to access a range number that is our of range. Negative test. 
TEST_F(CollectionTest, verifyLessThenThrowInCollection)
{
    add_entries(90);

    int maxNum = 99;

    for (auto i = collection->size(); i < maxNum; i++) {
        add_entries(1);
        EXPECT_LE(collection->size(), maxNum);
    }

    EXPECT_THROW(collection->at(99), std::out_of_range);
}